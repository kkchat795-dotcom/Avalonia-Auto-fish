package com.example.avaloniafishingauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/**
 * Starter service. This first build deliberately does not claim to read game text.
 * It exposes safe tap primitives for the next OCR/MediaProjection stage.
 */
class AutoClickAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var fishTest = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopLoop() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Toast.makeText(this, "Avalonia Auto: layanan aktif", Toast.LENGTH_SHORT).show()
    }

    fun startSwordLoop() {
        if (running) return
        running = true
        swordTick()
    }

    fun stopLoop() {
        running = false
        handler.removeCallbacksAndMessages(null)
    }

    private fun swordTick() {
        if (!running) return
        val p = getSharedPreferences("points", MODE_PRIVATE)
        val x = p.getFloat("sx", 90f) / 100f * resources.displayMetrics.widthPixels
        val y = p.getFloat("sy", 85f) / 100f * resources.displayMetrics.heightPixels
        tap(x, y)
        val delay = p.getLong("interval", 700L).coerceAtLeast(150L)
        handler.postDelayed({ swordTick() }, delay)
    }

    fun tapFishForTest() {
        val p = getSharedPreferences("points", MODE_PRIVATE)
        val x = p.getFloat("fx", 88f) / 100f * resources.displayMetrics.widthPixels
        val y = p.getFloat("fy", 74f) / 100f * resources.displayMetrics.heightPixels
        tap(x, y)
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 55))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
