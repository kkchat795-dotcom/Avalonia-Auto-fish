package com.example.avaloniafishingauto

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var swordX: EditText
    private lateinit var swordY: EditText
    private lateinit var fishX: EditText
    private lateinit var fishY: EditText
    private lateinit var interval: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
        }
        layout.addView(TextView(this).apply {
            text = "Avalonia Fishing Auto"
            textSize = 24f
        })
        layout.addView(TextView(this).apply {
            text = "Versi awal: atur titik klik dalam persen layar (0–100)."
            textSize = 14f
        })
        swordX = field(layout, "Pedang X (%)", "90")
        swordY = field(layout, "Pedang Y (%)", "85")
        fishX = field(layout, "Ikan X (%)", "88")
        fishY = field(layout, "Ikan Y (%)", "74")
        interval = field(layout, "Jeda ketukan pedang (ms)", "700")

        button(layout, "1. Aktifkan izin Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button(layout, "2. Izinkan tampil di atas aplikasi lain") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button(layout, "Simpan pengaturan") {
            val p = getSharedPreferences("points", MODE_PRIVATE).edit()
            p.putFloat("sx", value(swordX, 90f)); p.putFloat("sy", value(swordY, 85f))
            p.putFloat("fx", value(fishX, 88f)); p.putFloat("fy", value(fishY, 74f))
            p.putLong("interval", value(interval, 700f).toLong().coerceAtLeast(150))
            p.apply()
            Toast.makeText(this, "Pengaturan disimpan", Toast.LENGTH_SHORT).show()
        }
        button(layout, "Buka panduan penggunaan") {
            AlertDialog.Builder(this)
                .setTitle("Cara menggunakan")
                .setMessage("Aktifkan layanan Accessibility untuk aplikasi ini. Kembali ke game, lalu buka lagi aplikasi ini dan tekan tombol MULAI pada notifikasi/layanan. Versi awal ini menyediakan ketukan pedang dan tombol uji ketukan ikan; deteksi tulisan Fish Biting otomatis belum disertakan.")
                .setPositiveButton("Mengerti", null).show()
        }
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun field(parent: LinearLayout, label: String, initial: String): EditText {
        parent.addView(TextView(this).apply { text = label; textSize = 14f; setPadding(0, 16, 0, 4) })
        val e = EditText(this).apply {
            setSingleLine(true); setText(initial); inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        parent.addView(e)
        return e
    }
    private fun button(parent: LinearLayout, label: String, action: () -> Unit) {
        parent.addView(Button(this).apply { text = label; setOnClickListener { action() } })
    }
    private fun value(e: EditText, fallback: Float) = e.text.toString().toFloatOrNull()?.coerceIn(0f, 100f) ?: fallback
}
