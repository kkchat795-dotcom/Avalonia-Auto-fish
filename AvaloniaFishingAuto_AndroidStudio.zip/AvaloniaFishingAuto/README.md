# Avalonia Fishing Auto — starter project

Target awal: Android 11 (API 30). Project ini dibuat sebagai **starter Android Studio**, bukan APK siap pasang.

## Yang sudah disiapkan
- Project Kotlin Android.
- Form koordinat tombol Pedang dan Ikan dalam persen layar.
- Pengaturan jeda ketukan.
- Accessibility Service dengan fungsi gesture tap.
- Kerangka loop ketukan pedang dan fungsi uji ketukan ikan.

## Yang belum selesai
**Deteksi tulisan `Fish Biting!` otomatis belum diimplementasikan.** Untuk itu perlu tahap berikutnya memakai MediaProjection (izin rekam/tangkap layar dari Android) dan OCR, misalnya ML Kit Text Recognition. Karena game tidak menyediakan API status ikan, aplikasi perlu izin tangkap layar dan harus diuji pada resolusi/perangkatmu.

## Cara membuka
1. Ekstrak ZIP.
2. Buka folder `AvaloniaFishingAuto` melalui Android Studio.
3. Tunggu Gradle Sync.
4. Jalankan ke HP Android 11 dengan USB debugging.
5. Di aplikasi, aktifkan layanan Accessibility dan izin overlay bila diminta.
6. Atur koordinat tombol sesuai layar. Nilai koordinat adalah persentase dari lebar/tinggi layar.

## Catatan penting
- Nilai koordinat awal hanyalah contoh dan wajib dikalibrasi.
- Jangan aktifkan loop sebelum koordinat benar.
- Gunakan STOP/putuskan layanan Accessibility untuk menghentikan ketukan.
- Pastikan penggunaan sesuai aturan game.
